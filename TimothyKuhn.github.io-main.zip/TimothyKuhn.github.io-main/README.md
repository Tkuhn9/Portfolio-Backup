# TimothyKuhn.github.io
This is my portfolio for Data Analysis
